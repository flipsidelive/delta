﻿using System.Data.Entity;

namespace Delta
{
    public class DeltaContext : DbContext
    {
        public DeltaContext() : base("DeltaConnection")
        {
        }
       
        public DbSet<WorkItem> WorkItems { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<WorkItemCategory> WorkItemCategories { get; set; }
        public DbSet<EventCategory> EventCategories { get; set; }
        public DbSet<ChangeCategory> ChangeCategories { get; set; }
        public DbSet<Flow> Flows { get; set; }
        public DbSet<FlowStep> FlowSteps { get; set; }
        public DbSet<FlowGroup> FlowGroups { get; set; }
        public DbSet<FlowUser> FlowUsers { get; set; }
        public DbSet<FlowGroupStep> FlowGroupSteps { get; set; }
        public DbSet<FlowUserGroup> FlowUserGroup { get; set; }
        public DbSet<Change> Changes { get; set;}
        public DbSet<ChangeStep> ChangeSteps { get; set; }
        public DbSet<AttachedFile> AttachedFiles { get; set; }

        public System.Data.Entity.DbSet<Delta.ChangeMyActions> ChangeMyActions { get; set; }
    }
}