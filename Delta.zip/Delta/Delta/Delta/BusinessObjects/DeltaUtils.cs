﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using Delta;

/// <summary>
/// Methods to remove HTML from strings.
/// </summary>
public static class DeltaUtils
{    

    /// <summary>
    /// Compiled regular expression for performance.
    /// </summary>
    static Regex _htmlRegex = new Regex("<.*?>", RegexOptions.Compiled);

    /// <summary>
    /// Remove HTML from string with compiled Regex.
    /// </summary>
    public static string StripTagsRegexCompiled(string source)
    {
        return _htmlRegex.Replace(source, string.Empty);
    }
    public static string Left(string value, int maxLength)
    {
        if (string.IsNullOrEmpty(value)) return value;
        maxLength = Math.Abs(maxLength);

        return (value.Length <= maxLength
               ? value
               : value.Substring(0, maxLength)
               );
    }

    public static string CleanUsername(string inUser)
    {
        if (inUser != null)
        {
            string loweruser = inUser.Replace("WEBUYANYCAR\\", string.Empty).Replace('.', ' ');
            TextInfo myTI = new CultureInfo("en-GB", false).TextInfo;
            return myTI.ToTitleCase(loweruser);
        }
        else
        {
            return string.Empty;
        }
    }

    public static string TimelineColor(DateTime EventTime, int completed)
    {
        if (EventTime < DateTime.Today)
        {
            // past
            if (completed == 1)
            {
                return "navy-bg";
            }
            else
            {
                return "red-bg";
            }
        }
        else
        {
            //future
            return "lazur-bg";
        }
    }

    public static string TimelineIcon(DateTime EventTime, int completed)
    {
        if (EventTime < DateTime.Today)
        {
            // past
            if (completed == 1)
            {
                return "fa-check";
            }
            else
            {
                return "fa-warning";
            }            
        }
        else
        {
            //future
            return "fa-plus-square";
        }
    }

    public static string FormatEventDate(DateTime inDate)
    {
        int nod = (DateTime.Now - inDate).Days;
        if(nod < 0)
        {
            return "Planned";
        }
        else if (nod == 0)
        {
            return "Today";
        }
        else if (nod == 1)
        {
            return "Yesterday";
        }
        else if (nod >= 2 && nod <= 7)
        {
            return "Last few Days";
        }
        else if (nod >= 8 && nod <= 28)
        {
            return "Last Few Weeks";
        }
        else
        {
            return "Over a month ago";
        }
    }

    internal static List<StatusDropDown> GenerateValidStatuses(string status)
    {
        var toRet = new List<StatusDropDown>();

        switch (status)
        {
            case "New":
                toRet.Add(new StatusDropDown { StatusId = 0, StatusValue = "New" });
                toRet.Add(new StatusDropDown { StatusId = 1, StatusValue = "Removed" });
                toRet.Add(new StatusDropDown { StatusId = 2, StatusValue = "Approved" });
                toRet.Add(new StatusDropDown { StatusId = 3, StatusValue = "Committed" });
                toRet.Add(new StatusDropDown { StatusId = 5, StatusValue = "Done" });
                break;
            case "Removed":
                toRet.Add(new StatusDropDown { StatusId = 0, StatusValue = "New" });
                toRet.Add(new StatusDropDown { StatusId = 1, StatusValue = "Removed" });
                break;
            case "Approved":
                toRet.Add(new StatusDropDown { StatusId = 0, StatusValue = "New" });
                toRet.Add(new StatusDropDown { StatusId = 1, StatusValue = "Removed" });
                toRet.Add(new StatusDropDown { StatusId = 2, StatusValue = "Approved" });
                toRet.Add(new StatusDropDown { StatusId = 3, StatusValue = "Committed" });
                toRet.Add(new StatusDropDown { StatusId = 5, StatusValue = "Done" });
                break;
            case "Committed":
                toRet.Add(new StatusDropDown { StatusId = 0, StatusValue = "New" });
                toRet.Add(new StatusDropDown { StatusId = 1, StatusValue = "Removed" });
                toRet.Add(new StatusDropDown { StatusId = 2, StatusValue = "Approved" });
                toRet.Add(new StatusDropDown { StatusId = 3, StatusValue = "Committed" });
                toRet.Add(new StatusDropDown { StatusId = 4, StatusValue = "Testing" });
                break;
            case "Testing":
                toRet.Add(new StatusDropDown { StatusId = 1, StatusValue = "Removed" });
                toRet.Add(new StatusDropDown { StatusId = 3, StatusValue = "Committed" });
                toRet.Add(new StatusDropDown { StatusId = 4, StatusValue = "Testing" });
                toRet.Add(new StatusDropDown { StatusId = 5, StatusValue = "Done" });
                break;
            case "Done":
                toRet.Add(new StatusDropDown { StatusId = 0, StatusValue = "New" });
                toRet.Add(new StatusDropDown { StatusId = 1, StatusValue = "Removed" });
                toRet.Add(new StatusDropDown { StatusId = 2, StatusValue = "Approved" });
                toRet.Add(new StatusDropDown { StatusId = 3, StatusValue = "Committed" });
                toRet.Add(new StatusDropDown { StatusId = 4, StatusValue = "Testing" });
                toRet.Add(new StatusDropDown { StatusId = 5, StatusValue = "Done" });
                break;
        }       

        return toRet;
    }
}