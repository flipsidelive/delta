﻿using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace Delta
{
    public class TFSAccess
    {
        public List<OurWorkItem> GetWorkItems()
        {            
            WorkItemStore store = new WorkItemStore("http://wbacuktfs001/tfs/tfs360");
            string pbiQuery = "SELECT [Microsoft.VSTS.Common.BacklogPriority], [System.Title], [System.AssignedTo], [WBAC.RFCID], [System.IterationPath], [System.State] FROM WorkItems WHERE ( [System.WorkItemType] = 'Product Backlog Item'  OR  [System.WorkItemType] = 'Bug' ) AND  [System.State] <> 'Removed'  AND  [System.State] <> 'Done'  AND  (([System.TeamProject] = 'TeamLotus') or ([System.TeamProject] = 'TeamNoble') or ([System.TeamProject] = 'TeamMorgan') or ([System.TeamProject] = 'TeamAstonMartin')) ORDER BY [Microsoft.VSTS.Common.BacklogPriority]";
            WorkItemCollection witCollection = store.Query(pbiQuery);

            List<OurWorkItem> ret = new List<OurWorkItem>();
            foreach (Microsoft.TeamFoundation.WorkItemTracking.Client.WorkItem tfsItem in witCollection)
            {
                string assignedTo = tfsItem.Fields["Assigned To"].Value.ToString();

                int backlogPriority = 0;
                if (tfsItem.Fields["Backlog Priority"].Value != null)
                {
                    backlogPriority = int.Parse(tfsItem.Fields["Backlog Priority"].Value.ToString());
                }

                OurWorkItem newItem = new OurWorkItem
                {
                    WorkItemId = tfsItem.Id,
                    Title = tfsItem.Title,
                    AssignedTo = assignedTo,
                    BacklogPriority = backlogPriority,
                    CreatedBy = tfsItem.CreatedBy,
                    Project = tfsItem.Project.Name,
                    RemainingWork = "0",
                    Status = tfsItem.State,
                    CreatedDate = tfsItem.CreatedDate,
                    Description = tfsItem.Description
                };
                ret.Add(newItem);
            }
            return ret;
        }

        public OurWorkItem GetWorkItemById(int workItemId)
        {
            WorkItemStore store = new WorkItemStore("http://wbacuktfs001/tfs/tfs360");

            var tfsItem = store.GetWorkItem(workItemId);
            OurWorkItem newItem = null;

            if (tfsItem != null)
            {

                string assignedTo = tfsItem.Fields["Assigned To"].Value.ToString();

                int backlogPriority = 0;
                if (tfsItem.Fields["Backlog Priority"].Value != null)
                {
                    backlogPriority = int.Parse(tfsItem.Fields["Backlog Priority"].Value.ToString());
                }

                

                newItem = new OurWorkItem
                {
                    WorkItemId = tfsItem.Id,
                    Title = tfsItem.Title,
                    AssignedTo = assignedTo,
                    BacklogPriority = backlogPriority,
                    CreatedBy = tfsItem.CreatedBy,
                    Project = tfsItem.Project.Name,
                    RemainingWork = "0",
                    Status = tfsItem.State,
                    CreatedDate = tfsItem.CreatedDate,
                    Description = tfsItem.Description
                };

                if (tfsItem.AttachedFileCount > 0)
                {
                    foreach (Microsoft.TeamFoundation.WorkItemTracking.Client.Attachment fl in tfsItem.Attachments)
                    {
                        newItem.Attachments.Add(new OurWorkItemAttachment { Name = fl.Name, Url = fl.Uri.ToString() });
                    }
                }
            }                                           
            
            return newItem;
        }

        internal int NewTFSChange(WorkItem change, string ProjectName)
        {
            Uri url = new Uri("http://wbacuktfs001/tfs/tfs360");

            NetworkCredential nc = new NetworkCredential();

            TfsTeamProjectCollection coll = new TfsTeamProjectCollection(url);

            coll.EnsureAuthenticated();

            WorkItemStore workItemStore = coll.GetService<WorkItemStore>();
            Project teamproject = workItemStore.Projects[ProjectName.Replace(" ", string.Empty)];
            WorkItemType workItemType = teamproject.WorkItemTypes["Product Backlog Item"];

            Microsoft.TeamFoundation.WorkItemTracking.Client.WorkItem wi = new Microsoft.TeamFoundation.WorkItemTracking.Client.WorkItem(workItemType);
            wi.Title = change.Title;
            wi.Description = change.Description;
            wi.History = "Created By -" + change.Requestor;
            wi.Save();
            wi.State = change.Status.ToString();
            wi.Save();
            return wi.Id;
        }

        internal void SaveChange(WorkItem change)
        {
            WorkItemStore store = new WorkItemStore("http://wbacuktfs001/tfs/tfs360");
            var tfsItem = store.GetWorkItem(change.TeamWorkItemId);
            tfsItem.Title = change.Title;
            tfsItem.Description = change.Description;
            tfsItem.State = change.Status.ToString();
            tfsItem.Save();
        }

        internal void SaveAttachment(string AttachmentName, string AttachmentPath, int TFSWorkItemId)
        {
            WorkItemStore store = new WorkItemStore("http://wbacuktfs001/tfs/tfs360");
            var tfsItem = store.GetWorkItem(TFSWorkItemId);
            tfsItem.Attachments.Add(new Attachment(AttachmentPath, AttachmentName));
            tfsItem.Save();            
        }
    }
}