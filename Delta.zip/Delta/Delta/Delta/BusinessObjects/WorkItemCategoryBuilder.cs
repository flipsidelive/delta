﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Delta
{
    public class WorkItemCategoryBuilder
    { 

        public string HtmlGetChangeCategories(int? selected = null)
        {
            //var s =  "<li>Root node 1<ul><li> Child node 1 </li><li><a href=\"#\">Child node 2</a></li></ul></li>";
            var theCats = GetChangeCategories();
            StringBuilder sb = new StringBuilder("<div id=\"Categories\"><ul>");
            AddCatsToDisplay(theCats, sb, selected);

            sb.Append("</ul></div>");
            return sb.ToString();
        }

        private static void AddCatsToDisplay(List<WorkItemCategoryDisplay> theCats, StringBuilder sb, int? selected)
        {
            foreach (var thisCat in theCats)
            {
                sb.AppendFormat("<li id='{0}'>", thisCat.WorkItemCategoryId);
                
                if (selected == null)
                {
                    if (thisCat.Name == "Unknown")
                    {
                        sb.Append("<a href=\"#\" class=\"jstree-clicked\">Unknown</a>");
                    }
                }
                else
                {
                    if (thisCat.WorkItemCategoryId == selected)
                    {
                        sb.AppendFormat("<a href=\"#\" class=\"jstree-clicked\">{0}</a>", thisCat.Name);
                    }

                }
                

                sb.Append(thisCat.Name);
                sb.Append("<ul>");
                AddCatsToDisplay(thisCat.Children, sb, selected);
                sb.Append("</ul>");
                sb.Append("</li>");
            }
        }

        public List<WorkItemCategoryDisplay> GetChangeCategories()
        {
            List<WorkItemCategoryDisplay> ret = new List<WorkItemCategoryDisplay>();
            DeltaContext db = new DeltaContext();
            foreach (var c in db.WorkItemCategories)
            {
                if (c.ParentId == null)
                {
                    ret.Add(new WorkItemCategoryDisplay { WorkItemCategoryId = c.ChangeCategoryId, Name = c.Name});
                }
                else
                {
                    AddChild(ret, c);
                }
            }
            return ret;
        }

        public string GetCategoryNameById(int id)
        {
            DeltaContext db = new DeltaContext();
            return db.WorkItemCategories.First(m => m.ChangeCategoryId == id).Name;
        }

        private static void AddChild(List<WorkItemCategoryDisplay> ret, WorkItemCategory c)
        {
            foreach (var p in ret)
            {
                if (p.WorkItemCategoryId == c.ParentId)
                {
                    p.Children.Add(new WorkItemCategoryDisplay { WorkItemCategoryId = c.ChangeCategoryId, Name = c.Name });
                }
                AddChild(p.Children, c);
            }
        }
    }
}