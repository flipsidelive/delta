﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Delta
{
    public class Seed
    {



        public static void GetSeed()
        {
            string thisCommand = @"SELECT 
                                  [Title]
	                              ,'fromseed' as ShortDescription
                                  ,[Description]
	                              ,[TimeAdded] as 'CreatedDate'
	                              , null as CompletedDate
	                              ,WI.[System.State] as Status
	                              ,0 as Priority	  
	                              ,CASE
	  		                            when [WorkStream] = 'UK\Marketing' then '5'
			                            when [WorkStream] = 'UK\Web Sites' then '5'
			                            when [WorkStream] = 'UK\Carland' then '4'
			                            when [WorkStream] = 'UK\Operations' then '3'
			                            when [WorkStream] = 'UK\Retail' then '3'
			                            when [WorkStream] = 'Retail' then '3'
			                            when [WorkStream] = 'UK\Commercial' then '3'
			                            when [WorkStream] = 'UK\DBA' then '2'
			                            when [WorkStream] = 'UK\Databases' then '2'
			                            else [System.AreaPath]
			                            end as 'Category'       
                                  --,[BacklogPriority]
                                  ,[CreatedBy] as 'Requestor'     
                                  ,[WorkItemId]
	  
                              FROM [TfsBuffer].[dbo].[TriageItems] TI
                              left join  [Tfs_TFS360].[dbo].[WorkItemsAreUsed] WI on wi.[System.Id] = ti.WorkItemId  
                              where TimeAdded > GETDATE() - 120 and Rejected = 0 and  (WI.[System.State] <> 'Done' and WI.[System.State] <> 'Removed')  
                              order by TimeAdded";
            SeedThis(thisCommand, true);

            string thatCommand = @"SELECT
                                    [Title]
            	                    ,'' as ShortDescription
                                    ,[Description]
            	                    ,[TimeAdded] as 'CreatedDate'
            	                    , null as CompletedDate	  
                                    , 'New' as Status
            	                    ,0 as Priority	  
            	                    ,CASE
                                        when[WorkStream] = 'UK\Marketing' then '5'
            			                when[WorkStream] = 'UK\Web Sites' then '5'
            			                when[WorkStream] = 'UK\Carland' then '4'
            			                when[WorkStream] = 'UK\Operations' then '3'
            			                when[WorkStream] = 'UK\Retail' then '3'
            			                when[WorkStream] = 'Retail' then '3'
            			                when[WorkStream] = 'UK\Commercial' then '3'
            			                when[WorkStream] = 'UK\DBA' then '2'
            			                when[WorkStream] = 'UK\Databases' then '2'
            			                else '0'
            			            end as 'Category'             
                                    ,[CreatedBy] as 'Requestor'     
                                    ,[WorkItemId]
                                    FROM[TfsBuffer].[dbo].[TriageItems] TI
                                    where TimeAdded > GETDATE() - 120 and Rejected = 0 and WorkItemId is null 
                                    order by TimeAdded";
                SeedThis(thatCommand);
    }

        private static void SeedThis(string thisCommand , bool withTFS = false)
        {
            SqlConnection sqlConn = new SqlConnection(@"Data Source=WBACUKSQLDW001\i2;Initial Catalog=TfsBuffer;Integrated Security=True");
            sqlConn.Open();


            SqlCommand sqlcom = new SqlCommand(thisCommand, sqlConn);
            SqlDataReader dr = sqlcom.ExecuteReader();
            DeltaContext db = new DeltaContext();
            while (dr.Read())
            {
                string SeedTitle = dr["Title"].ToString();                
                string SeedDescription = dr["Description"].ToString();
                if (SeedDescription == string.Empty)
                {
                    SeedDescription = SeedTitle;
                }
                string SeedShortDescription = DeltaUtils.StripTagsRegexCompiled(SeedDescription).Replace("&nbsp", " ");
                string SeedCreatedDate = dr["CreatedDate"].ToString();
                string SeedCompletedDate = dr["CompletedDate"].ToString();
                string SeedStatus = dr["Status"].ToString();
                string SeedPriority = dr["Priority"].ToString();
                string SeedCategory = dr["Category"].ToString();
                string SeedRequestor = dr["Requestor"].ToString();
                if (!withTFS)
                {
                    WorkItem ch = new WorkItem { Category = int.Parse(SeedCategory), CreatedDate = DateTime.Parse(SeedCreatedDate), Description = SeedDescription, Priority = PriorityEnum.Medium, Requestor = SeedRequestor, ShortDescription = SeedShortDescription, Status = (StatusEnum)Enum.Parse(typeof(StatusEnum), SeedStatus), Title = SeedTitle };
                    db.WorkItems.Add(ch);
                }
                else
                {
                    SeedTitle = "TFS" + SeedTitle;
                    string SeedWorkItemId = dr["WorkItemId"].ToString();
                    WorkItem ch = new WorkItem { Category = int.Parse(SeedCategory), CreatedDate = DateTime.Parse(SeedCreatedDate), Description = SeedDescription, Priority = PriorityEnum.Medium, Requestor = SeedRequestor, ShortDescription = SeedShortDescription, Status = (StatusEnum)Enum.Parse(typeof(StatusEnum), SeedStatus), Title = SeedTitle, TeamWorkItemId = int.Parse(SeedWorkItemId) };
                    db.WorkItems.Add(ch);
                }

                
                try
                {
                    db.SaveChanges();
                }
                catch (Exception e)
                {

                    throw;
                }

            }

            sqlConn.Close();
        }
    }
}