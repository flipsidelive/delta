﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Delta
{
    public class EventCategoryBuilder
    { 

        public string HtmlGetEventCategories(int? selected = null)
        {
            //var s =  "<li>Root node 1<ul><li> Child node 1 </li><li><a href=\"#\">Child node 2</a></li></ul></li>";
            var theCats = GetChangeCategories();
            StringBuilder sb = new StringBuilder("<div id=\"Categories\"><ul>");
            AddEventsToDisplay(theCats, sb, selected);

            sb.Append("</ul></div>");
            return sb.ToString();
        }

        private static void AddEventsToDisplay(List<EventCategoryDisplay> theCats, StringBuilder sb, int? selected)
        {
            foreach (var thisCat in theCats)
            {
                sb.AppendFormat("<li id='{0}'>", thisCat.EventCategoryId);
                
                if (selected == null)
                {
                    if (thisCat.Name == "Unknown")
                    {
                        sb.Append("<a href=\"#\" class=\"jstree-clicked\">Unknown</a>");
                    }
                }
                else
                {
                    if (thisCat.EventCategoryId == selected)
                    {
                        sb.AppendFormat("<a href=\"#\" class=\"jstree-clicked\">{0}</a>", thisCat.Name);
                    }

                }
                

                sb.Append(thisCat.Name);
                sb.Append("<ul>");
                AddEventsToDisplay(thisCat.Children, sb, selected);
                sb.Append("</ul>");
                sb.Append("</li>");
            }
        }

        public List<EventCategoryDisplay> GetChangeCategories()
        {
            List<EventCategoryDisplay> ret = new List<EventCategoryDisplay>();
            DeltaContext db = new DeltaContext();
            foreach (var c in db.EventCategories)
            {
                if (c.ParentId == null)
                {
                    ret.Add(new EventCategoryDisplay { EventCategoryId = c.EventCategoryId, Name = c.Name});
                }
                else
                {
                    AddChild(ret, c);
                }
            }
            return ret;
        }

        public string GetEventCategoryNameById(int id)
        {
            DeltaContext db = new DeltaContext();
            return db.EventCategories.First(m => m.EventCategoryId == id).Name;
        }

        private static void AddChild(List<EventCategoryDisplay> ret, EventCategory c)
        {
            foreach (var p in ret)
            {
                if (p.EventCategoryId == c.ParentId)
                {
                    p.Children.Add(new EventCategoryDisplay { EventCategoryId = c.EventCategoryId, Name = c.Name });
                }
                AddChild(p.Children, c);
            }
        }
    }
}