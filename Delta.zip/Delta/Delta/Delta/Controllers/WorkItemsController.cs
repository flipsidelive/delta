﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Delta;
using System.Globalization;
using System.IO;
using System.Web.Hosting;

namespace Delta.Controllers
{
    public class WorkItemsController : Controller
    {
        private DeltaContext db = new DeltaContext();

        // GET: Changes
        public ActionResult Index()
        {
            

            List<WorkItemDisplay> thisList = new List<WorkItemDisplay>();
            List<WorkItemDisplay> tfsList = new List<WorkItemDisplay>();

            TFSAccess acc = new TFSAccess();
            var tfsItems = acc.GetWorkItems();
            foreach (var t in tfsItems)
            {
                tfsList.Add(
                    new WorkItemDisplay
                    {
                        Title = t.Title,
                        Category = t.Project,
                        WorkItemId = 0,
                        CreatedDate = DateTime.Now,
                        ShortDescription = ""
                    });
            }


            var origList = (from ch in db.WorkItems
                            join ct in db.WorkItemCategories on ch.Category equals ct.ChangeCategoryId
                            where ch.Status != StatusEnum.Done
                            select new { ch, ct }).ToList();

            foreach(var o in origList)
            {
                if (o.ch.TeamWorkItemId == 0)
                {                    
                    string sortedRequestor = DeltaUtils.CleanUsername(o.ch.Requestor);
                    thisList.Add(
                        new WorkItemDisplay
                        {
                            Title = o.ch.Title,
                            WorkItemId = o.ch.WorkItemId,
                            Category = o.ct.Name,
                            CompletedDate = o.ch.CompletedDate,
                            CreatedDate = o.ch.CreatedDate,
                            Description = o.ch.Description,
                            Priority = o.ch.Priority,
                            CleanedRequestor = sortedRequestor,
                            ShortDescription = DeltaUtils.Left(o.ch.ShortDescription, 500),
                            Status = o.ch.Status.ToString()
                        });
                }
                else
                {
                    var specItem = tfsItems.Find(p => p.WorkItemId == o.ch.TeamWorkItemId);
                    if (specItem == null)
                    {
                        string sortedRequestor = DeltaUtils.CleanUsername(o.ch.Requestor);
                        thisList.Add(
                            new WorkItemDisplay
                            {
                                Title = o.ch.Title,
                                WorkItemId = o.ch.WorkItemId,
                                Category = o.ct.Name,
                                CompletedDate = o.ch.CompletedDate,
                                CreatedDate = o.ch.CreatedDate,
                                Description = o.ch.Description,
                                Priority = o.ch.Priority,
                                CleanedRequestor = sortedRequestor,
                                ShortDescription = DeltaUtils.Left(o.ch.ShortDescription, 500),
                                Status = o.ch.Status.ToString()
                            });
                    }
                    else
                    {
                        string sortedRequestor = DeltaUtils.CleanUsername(o.ch.Requestor);
                        thisList.Add(
                            new WorkItemDisplay
                            {
                                Title = specItem.Title,
                                WorkItemId = o.ch.WorkItemId,
                                Category = o.ct.Name,
                                CompletedDate = o.ch.CompletedDate,
                                CreatedDate = o.ch.CreatedDate,
                                Description = specItem.Description,
                                Priority = o.ch.Priority,
                                CleanedRequestor = sortedRequestor,
                                ShortDescription = DeltaUtils.Left(DeltaUtils.StripTagsRegexCompiled(specItem.Description), 500),
                                Status = o.ch.Status.ToString(),
                                TfsWorkItemId = specItem.WorkItemId
                            });
                    }
                }
                
            }                      

            return View(thisList);
        }

        [HttpPost]
        public ActionResult AddFile()
        {
            bool isSavedSuccessfully = true;
            string fName = "";
            List<int> idAdd = new List<int>();
            try
            {
                foreach (string fileName in Request.Files)
                {
                    HttpPostedFileBase file = Request.Files[fileName];
                    //Save file content goes here
                    fName = file.FileName;
                    if (file != null && file.ContentLength > 0)
                    {
                        AttachedFile af = new AttachedFile();
                        af.FileName = fName;
                        af.FilePath = "Temp";
                        af.AttachmentType = "W"; //For WorkItem
                        af.AttachedDate = DateTime.Now;
                        DeltaContext dc = new DeltaContext();
                        dc.AttachedFiles.Add(af);
                        dc.SaveChanges();
                        var originalDirectory = new DirectoryInfo(string.Format("{0}Images\\TempFiles", Server.MapPath(@"\")));
                        string pathString = System.IO.Path.Combine(originalDirectory.ToString(), af.AttachedFileId.ToString());

                        bool isExists = System.IO.Directory.Exists(pathString);
                        if (!isExists)
                            System.IO.Directory.CreateDirectory(pathString);
                        var path = string.Format("{0}\\{1}", pathString, file.FileName);
                        file.SaveAs(path);
                        idAdd.Add(af.AttachedFileId);
                    }

                }

            }
            catch (Exception ex)
            {
                isSavedSuccessfully = false;
            }


            if (isSavedSuccessfully)
            {
                return Json(new { Message = fName, id = string.Join(",", idAdd) });
            }
            else
            {
                return Json(new { Message = "Error in saving file" });
            }
        }


        public ActionResult MyChanges()
        {
            //Seed.GetSeed();

            List<WorkItemDisplay> thisList = new List<WorkItemDisplay>();
            List<WorkItemDisplay> tfsList = new List<WorkItemDisplay>();

            TFSAccess acc = new TFSAccess();
            var tfsItems = acc.GetWorkItems();
            foreach (var t in tfsItems)
            {
                tfsList.Add(
                    new WorkItemDisplay
                    {
                        Title = t.Title,
                        Category = t.Project,
                        WorkItemId = 0,
                        CreatedDate = DateTime.Now,
                        ShortDescription = ""
                    });
            }


            var origList = (from ch in db.WorkItems
                            join ct in db.WorkItemCategories on ch.Category equals ct.ChangeCategoryId
                            where ch.Requestor == User.Identity.Name
                            select new { ch, ct }).ToList();

            foreach (var o in origList)
            {
                if (o.ch.TeamWorkItemId == 0)
                {
                    string sortedRequestor = DeltaUtils.CleanUsername(o.ch.Requestor);
                    thisList.Add(
                        new WorkItemDisplay
                        {
                            Title = o.ch.Title,
                            WorkItemId = o.ch.WorkItemId,
                            Category = o.ct.Name,
                            CompletedDate = o.ch.CompletedDate,
                            CreatedDate = o.ch.CreatedDate,
                            Description = o.ch.Description,
                            Priority = o.ch.Priority,
                            CleanedRequestor = sortedRequestor,
                            ShortDescription = DeltaUtils.Left(o.ch.ShortDescription, 500),
                            Status = o.ch.Status.ToString()
                        });
                }
                else
                {
                    var specItem = tfsItems.Find(p => p.WorkItemId == o.ch.TeamWorkItemId);
                    if (specItem == null)
                    {
                        string sortedRequestor = DeltaUtils.CleanUsername(o.ch.Requestor);
                        thisList.Add(
                            new WorkItemDisplay
                            {
                                Title = o.ch.Title,
                                WorkItemId = o.ch.WorkItemId,
                                Category = o.ct.Name,
                                CompletedDate = o.ch.CompletedDate,
                                CreatedDate = o.ch.CreatedDate,
                                Description = o.ch.Description,
                                Priority = o.ch.Priority,
                                CleanedRequestor = sortedRequestor,
                                ShortDescription = DeltaUtils.Left(o.ch.ShortDescription, 500),
                                Status = o.ch.Status.ToString()
                            });
                    }
                    else
                    {
                        string sortedRequestor = DeltaUtils.CleanUsername(o.ch.Requestor);
                        thisList.Add(
                            new WorkItemDisplay
                            {
                                Title = specItem.Title,
                                WorkItemId = o.ch.WorkItemId,
                                Category = o.ct.Name,
                                CompletedDate = o.ch.CompletedDate,
                                CreatedDate = o.ch.CreatedDate,
                                Description = specItem.Description,
                                Priority = o.ch.Priority,
                                CleanedRequestor = sortedRequestor,
                                ShortDescription = DeltaUtils.Left(DeltaUtils.StripTagsRegexCompiled(specItem.Description), 500),
                                Status = o.ch.Status.ToString(),
                                TfsWorkItemId = specItem.WorkItemId
                            });
                    }
                }

            }

            return View(thisList);
        }

        // GET: Changes/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Changes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ChangeId,Title,ShortDescription,Description,Category,CreatedDate,CompletedDate,Status,Priority")] WorkItem change, [Bind(Include = "FileIds")]string FileIds)
        {
            if (ModelState.IsValid)
            {
                change.CreatedDate = DateTime.Now;
                change.ShortDescription = DeltaUtils.StripTagsRegexCompiled(change.Description).Replace("&nbsp", "");
                change.Requestor = User.Identity.Name;
                db.WorkItems.Add(change);
                db.SaveChanges();
                SaveFilesToEvent(FileIds, change.WorkItemId);
                return RedirectToAction("Index");
            }

            return View(change);
        }

        private void SaveFilesToEvent(string newEventFileIds, int evEventId, int InTfs = 0)
        {
            if (newEventFileIds.Length > 0)
            {
                string[] proIDs = newEventFileIds.Replace("\"", "").Replace("[", "").Replace("]", "").Split(',');

                var destinationDirectory = new DirectoryInfo(string.Format("{0}Images\\StoredFiles", Server.MapPath(@"\")));
                string destinationIDDirectory = System.IO.Path.Combine(destinationDirectory.ToString(), "W" + evEventId.ToString());

                bool isExists = System.IO.Directory.Exists(destinationIDDirectory);
                if (!isExists)
                    System.IO.Directory.CreateDirectory(destinationIDDirectory);       

                foreach (var s in proIDs)
                {
                    int si = int.Parse(s);
                    var thisFileRecord = db.AttachedFiles.Where(ro => ro.AttachedFileId == si).FirstOrDefault();
                    var sourceDirectory = new DirectoryInfo(string.Format("{0}Images\\TempFiles", Server.MapPath(@"\")));
                    string sourceIDDirectory = System.IO.Path.Combine(sourceDirectory.ToString(), s);
                    string sourceFile = System.IO.Path.Combine(sourceIDDirectory, thisFileRecord.FileName);
                    string destFile = System.IO.Path.Combine(destinationIDDirectory, thisFileRecord.FileName);
                    System.IO.File.Move(sourceFile, destFile);
                    System.IO.Directory.Delete(sourceIDDirectory);
                    thisFileRecord.FilePath = destFile;
                    thisFileRecord.ParentId = evEventId;
                    db.Entry(thisFileRecord).State = EntityState.Modified;
                    db.SaveChanges();
                    if (InTfs != 0)
                    {
                        TFSAccess tf = new TFSAccess();
                        tf.SaveAttachment(destFile, destFile, InTfs);
                    }
                }
            }
        }

        // GET: Changes/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                Response.Redirect("/");                
            }
            WorkItem change = db.WorkItems.Find(id);
            if (change == null)
            {
                return HttpNotFound();
            }

            WorkItemDisplay thisChange = new WorkItemDisplay { CategoryId = change.Category, WorkItemId = change.WorkItemId, CompletedDate = change.CompletedDate, CreatedDate = change.CreatedDate, Description = change.Description, Priority = change.Priority, Requestor = change.Requestor, CleanedRequestor = DeltaUtils.CleanUsername(change.Requestor), ShortDescription = DeltaUtils.StripTagsRegexCompiled(change.Description), Status = change.Status.ToString(), Title = change.Title, TfsWorkItemId = change.TeamWorkItemId };

            if (change.TeamWorkItemId != 0)
            {
                TFSAccess tf = new TFSAccess();
                var tfItem = tf.GetWorkItemById(change.TeamWorkItemId);
                if (tfItem != null)
                {
                    thisChange.Title = tfItem.Title;
                    thisChange.Description = tfItem.Description;
                    thisChange.Status =  tfItem.Status;

                    foreach(OurWorkItemAttachment wif in tfItem.Attachments)
                    {
                        thisChange.AttachedFiles.Add(new AttachedFile { FileName = wif.Name, FilePath = wif.Url });
                    }
                }
            }
            else  //This isn't managed in TFS so get attachments from disk
            {
                var AttachedFiles = (from af in db.AttachedFiles
                                     where af.AttachmentType == "W" && af.ParentId == thisChange.WorkItemId
                                     select new { af.FileName, af.FilePath }).ToList();
                
                if (AttachedFiles.Count > 0)
                {
                    foreach (var AttachedFile in AttachedFiles)
                    {
                        thisChange.AttachedFiles.Add(new Delta.AttachedFile { FileName = AttachedFile.FileName, FilePath = MapPathReverse(AttachedFile.FilePath) });
                    }
                }

            }
            thisChange.StatusDrop = DeltaUtils.GenerateValidStatuses(thisChange.Status);
            thisChange.StatusId = (int)(StatusEnum)Enum.Parse(typeof(StatusEnum), thisChange.Status);


            //var ev = (from ch in db.Changes
            //          join cursp in db.FlowSteps on ch.CurrentStep equals cursp.FlowStepId
            //          join cat in db.ChangeCategories on ch.Category equals cat.ChangeCategoryId
            //          where ch.ChangeId == id
            //          select new { ch.ChangeId, ch.Title, ch.ShortDescription, ch.Description, cat.Name, cursp.StepName, ch.CurrentStep }).FirstOrDefault();
            //var ActNames = (from fsp in db.FlowSteps where fsp.FlowStepParentId == ev.CurrentStep select new { fsp.TransitionIn }).ToList();

            int pr = (from fg in db.FlowGroups
                      join fug in db.FlowUserGroup on fg.FlowGroupId equals fug.FlowGroupId
                      join fu in db.FlowUsers on fug.FlowUserId equals fu.FlowUserId
                      where fg.Name == "MoveToTFS" && fu.Name == User.Identity.Name
                      select fug.FlowUserGroupId).Count();
            thisChange.MoveToTfsPermission = (pr > 0);

            return View(thisChange);
        }

        public static string MapPathReverse(string AbsolutePath)
        {
            return AbsolutePath.Replace(HostingEnvironment.ApplicationPhysicalPath, "/").Replace(@"\", "/");
        }

        // POST: Changes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ChangeId,Title,ShortDescription,Description,CreatedDate,CompletedDate,Status,WorkItemId,Category,Requestor,Priority,StatusId,CategoryId")] WorkItemDisplay change, [Bind(Include = "FileIds")] string FileIds)
        {
            if (ModelState.IsValid)
            {
                WorkItem newChange = new WorkItem {  Category = change.CategoryId, WorkItemId = change.WorkItemId, CompletedDate = change.CompletedDate, CreatedDate = change.CreatedDate, Description = change.Description, Priority = change.Priority, Requestor = change.Requestor, ShortDescription = DeltaUtils.StripTagsRegexCompiled(change.Description), Title = change.Title, TeamWorkItemId = change.TfsWorkItemId};                
                newChange.Status = (StatusEnum)change.StatusId;
                db.Entry(newChange).State = EntityState.Modified;
                db.SaveChanges();                

                if (change.TfsWorkItemId != 0)
                {
                    TFSAccess tf = new TFSAccess();
                    tf.SaveChange(newChange);
                }

                SaveFilesToEvent(FileIds, newChange.WorkItemId, change.TfsWorkItemId);

                return RedirectToAction("Index");
            }
            return View(change);
        }

        public ActionResult MoveToTFS(int? id)
        {
            if (id == null)
            {
                Response.Redirect("/");
            }
            WorkItem change = db.WorkItems.Find(id);
            if (change == null)
            {
                return HttpNotFound();
            }
            TFSAccess tf = new TFSAccess();            
            WorkItemCategoryBuilder cb = new WorkItemCategoryBuilder();
            var tfsId = tf.NewTFSChange(change, cb.GetCategoryNameById(change.Category));

            //Try to add attachments.
            List<AttachedFile> attaItems = db.AttachedFiles.Where(rd => rd.ParentId == id && rd.AttachmentType == "W").ToList<AttachedFile>();
            if (attaItems.Count > 0)
            {
                foreach(AttachedFile af in attaItems)
                {
                    tf.SaveAttachment(af.FileName, af.FilePath, tfsId);
                }
            }

            change.TeamWorkItemId = tfsId;
            db.Entry(change).State = EntityState.Modified;
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
