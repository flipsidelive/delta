﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace Delta.Controllers
{
    public class EventsController : Controller
    {
        private DeltaContext db = new DeltaContext();
        // GET: Events
        public ActionResult Index()
        {
            List<EventDisplay> ed = new List<EventDisplay>();
            var origList = (from ev in db.Events
                            join ct in db.EventCategories on ev.Category equals ct.EventCategoryId
                            select new { ev, ct }).ToList();

            foreach (var o in origList)
            {
                
                string sortedRequestor = DeltaUtils.CleanUsername(o.ev.Requestor);
                ed.Add(
                    new EventDisplay
                    {
                        Title = o.ev.Title,
                        EventId = o.ev.EventId,
                        CategoryName = o.ct.Name,                        
                        CreatedDate = o.ev.CreatedDate,
                        Description = o.ev.Description,
                        CleanedRequestor = sortedRequestor,
                        EventDate = o.ev.EventDate,
                        Planned = o.ev.Planned,
                        Status = o.ev.Status,
                        StatusText = SetStatusText(o.ev.Status),                        
                        ShortDescription = DeltaUtils.Left(o.ev.ShortDescription, 500),
                        Confirmer = o.ev.Confirmer
                       // Status = o.ch.Status.ToString()
                    });                                
            }
            return View(ed);
        }

        public ActionResult Unconfirmed()
        {
            List<EventDisplay> ed = new List<EventDisplay>();
            var origList = (from ev in db.Events
                            join ct in db.EventCategories on ev.Category equals ct.EventCategoryId
                            where ev.Status == 0
                            select new { ev, ct }).ToList();

            foreach (var o in origList)
            {

                string sortedRequestor = DeltaUtils.CleanUsername(o.ev.Requestor);
                ed.Add(
                    new EventDisplay
                    {
                        Title = o.ev.Title,
                        EventId = o.ev.EventId,
                        CategoryName = o.ct.Name,
                        CreatedDate = o.ev.CreatedDate,
                        Description = o.ev.Description,
                        CleanedRequestor = sortedRequestor,
                        EventDate = o.ev.EventDate,
                        Planned = o.ev.Planned,
                        Status = o.ev.Status,
                        StatusText = SetStatusText(o.ev.Status),
                        ShortDescription = DeltaUtils.Left(o.ev.ShortDescription, 500),
                        Confirmer = o.ev.Confirmer
                        // Status = o.ch.Status.ToString()
                    });
            }
            return View(ed);
        }

        private string SetStatusText(int status)
        {
            if (status == 0)
            {
                return "Pending";
            }
            else
            {
                return "Completed";
            }
        }

        public ActionResult Create()
        {
            EventDisplay ev = new EventDisplay();
            ev.EventDate = DateTime.Now;
            ev.Requestor = User.Identity.Name;
            return View(ev);
        }

        [HttpPost]        
        public ActionResult AddFile()
        {
            bool isSavedSuccessfully = true;
            string fName = "";
            List<int> idAdd = new List<int>();
            try
            {
                foreach (string fileName in Request.Files)
                {
                    HttpPostedFileBase file = Request.Files[fileName];
                    //Save file content goes here
                    fName = file.FileName;
                    if (file != null && file.ContentLength > 0)
                    {
                        AttachedFile af = new AttachedFile();
                        af.FileName = fName;
                        af.FilePath = "Temp";
                        af.AttachmentType = "E"; //For Event
                        af.AttachedDate = DateTime.Now;
                        DeltaContext dc = new DeltaContext();
                        dc.AttachedFiles.Add(af);
                        dc.SaveChanges();
                        var originalDirectory = new DirectoryInfo(string.Format("{0}Images\\TempFiles", Server.MapPath(@"\")));
                        string pathString = System.IO.Path.Combine(originalDirectory.ToString(), af.AttachedFileId.ToString());                    
                        
                        bool isExists = System.IO.Directory.Exists(pathString);                 
                        if (!isExists)
                            System.IO.Directory.CreateDirectory(pathString);
                        var path = string.Format("{0}\\{1}", pathString, file.FileName);
                        file.SaveAs(path);
                        idAdd.Add(af.AttachedFileId);             
                    }

                }

            }
            catch (Exception ex)
            {
                isSavedSuccessfully = false;
            }


            if (isSavedSuccessfully)
            {
                return Json(new { Message = fName, id = string.Join(",", idAdd) });
            }
            else
            {
                return Json(new { Message = "Error in saving file" });
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EventId,Title,Description,Category,Requestor,Status,Priority,Planned,EventDateString,EventTimeString,FileIds")] EventDisplay newEvent)
        {
            if (ModelState.IsValid)
            {



                Event ev = new Event();
                ev.Category = newEvent.Category;
                ev.CreatedDate = DateTime.Now;
                ev.Description = newEvent.Description;
                ev.ShortDescription = DeltaUtils.StripTagsRegexCompiled(newEvent.Description);
                ev.Planned = newEvent.Planned;
                ev.Title = newEvent.Title;
                ev.Requestor = newEvent.Requestor;
                if (newEvent.Planned)
                {
                    ev.Status = 0;
                    DateTime dt = Convert.ToDateTime(newEvent.EventDateString + " " + newEvent.EventTimeString);
                    ev.EventDate = dt;
                }
                else
                {
                    ev.Status = 1;
                    ev.EventDate = DateTime.Now;
                    ev.Confirmer = User.Identity.Name;
                }

                db.Events.Add(ev);
                db.SaveChanges();
                SaveFilesToEvent(newEvent.FileIds, ev.EventId);

                return RedirectToAction("Index");
            }

            return View(newEvent);

        }

        private void SaveFilesToEvent(string newEventFileIds, int evEventId)
        {
            if (newEventFileIds.Length > 0)
            {
                string[] proIDs = newEventFileIds.Replace("\"", "").Replace("[", "").Replace("]", "").Split(',');

                var destinationDirectory = new DirectoryInfo(string.Format("{0}Images\\StoredFiles", Server.MapPath(@"\")));
                string destinationIDDirectory = System.IO.Path.Combine(destinationDirectory.ToString(), "E"+evEventId.ToString());

                bool isExists = System.IO.Directory.Exists(destinationIDDirectory);
                if (!isExists)
                    System.IO.Directory.CreateDirectory(destinationIDDirectory);


                foreach (var s in proIDs)
                {
                    int si = int.Parse(s);
                    var thisFileRecord = db.AttachedFiles.Where(ro => ro.AttachedFileId == si).FirstOrDefault();
                    var sourceDirectory = new DirectoryInfo(string.Format("{0}Images\\TempFiles", Server.MapPath(@"\")));
                    string sourceIDDirectory = System.IO.Path.Combine(sourceDirectory.ToString(), s);
                    string sourceFile = System.IO.Path.Combine(sourceIDDirectory, thisFileRecord.FileName);
                    string destFile = System.IO.Path.Combine(destinationIDDirectory, thisFileRecord.FileName);
                    System.IO.File.Move(sourceFile, destFile);
                    System.IO.Directory.Delete(sourceIDDirectory);
                    thisFileRecord.FilePath = destFile;
                    thisFileRecord.ParentId = evEventId;
                    db.Entry(thisFileRecord).State = EntityState.Modified;
                    db.SaveChanges();
                }
            }
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                Response.Redirect("/");
            }
            Event ev = db.Events.Find(id);
            if (ev == null)
            {
                return HttpNotFound();
            }
            EventCategoryBuilder ebdr = new EventCategoryBuilder();
            EventDisplay ed = new EventDisplay
            {
                Category = ev.Category,
                CategoryName = ebdr.GetEventCategoryNameById(ev.Category),
                CleanedRequestor = DeltaUtils.CleanUsername(ev.Requestor),
                Confirmer = ev.Confirmer,
                CreatedDate = ev.CreatedDate,
                Description = ev.Description,
                EventDate = ev.EventDate,
                EventDateString = ev.EventDate.ToString("dd/MM/yyyy"),
                EventId = ev.EventId,
                EventTimeString = ev.EventDate.ToString("hh:mm"),
                Planned = ev.Planned,
                Requestor = ev.Requestor,
                ShortDescription = DeltaUtils.StripTagsRegexCompiled(ev.Description),
                Status = ev.Status,
                StatusText = (ev.Status == 0) ? "Pending" : "Completed",
                Title = ev.Title          
            };

            var AttachedFiles = (from af in db.AttachedFiles
                                 where af.AttachmentType == "E" && af.ParentId == ev.EventId
                                 select new { af.FileName, af.FilePath }  ).ToList();

            ed.AttachedFiles = new List<AttachedFile>();
            if (AttachedFiles.Count > 0)
            {                                
                foreach (var AttachedFile in AttachedFiles)
                {
                    ed.AttachedFiles.Add(new Delta.AttachedFile { FileName = AttachedFile.FileName, FilePath = MapPathReverse(AttachedFile.FilePath) });
                }
            }
            

            return View(ed);
        }

        public static string MapPathReverse(string AbsolutePath)
        {
            return AbsolutePath.Replace(HostingEnvironment.ApplicationPhysicalPath, "/").Replace(@"\", "/");            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "EventId,Title,Description,Category,Requestor,Status,Priority,Planned,EventDateString,EventTimeString,Confirmer,CreatedDate,EventDate,FileIds")] EventDisplay evt)
        {
            if (ModelState.IsValid)
            {
                Event newEvent = new Event
                {
                    Category = evt.Category,
                    Confirmer = evt.Confirmer,
                    CreatedDate = evt.CreatedDate,
                    Description = evt.Description,
                    EventDate = evt.EventDate,
                    EventId = evt.EventId,
                    Planned = evt.Planned,
                    Requestor = evt.Requestor,
                    ShortDescription = DeltaUtils.StripTagsRegexCompiled(evt.Description),
                    Status = evt.Status,
                    Title = evt.Title
                };
                db.Entry(newEvent).State = EntityState.Modified;
                db.SaveChanges();

                SaveFilesToEvent(evt.FileIds, newEvent.EventId);

                return RedirectToAction("Index");
            }
            return View(evt);
        }

        public ActionResult Confirm(int? id)
        {
            if (id == null)
            {
                Response.Redirect("/");
            }
            Event ev = db.Events.Find(id);
            if (ev == null)
            {
                return HttpNotFound();
            }
            EventCategoryBuilder ebdr = new EventCategoryBuilder();
            EventDisplay ed = new EventDisplay
            {
                Category = ev.Category,
                CategoryName = ebdr.GetEventCategoryNameById(ev.Category),
                CleanedRequestor = DeltaUtils.CleanUsername(ev.Requestor),
                Confirmer = ev.Confirmer,
                CreatedDate = ev.CreatedDate,
                Description = ev.Description,
                EventDate = ev.EventDate,
                EventDateString = ev.EventDate.ToString("dd/MM/yyyy"),
                EventId = ev.EventId,
                EventTimeString = ev.EventDate.ToString("hh:mm"),
                Planned = ev.Planned,
                Requestor = ev.Requestor,
                ShortDescription = DeltaUtils.StripTagsRegexCompiled(ev.Description),
                Status = ev.Status,
                StatusText = (ev.Status == 0) ? "Pending" : "Completed",
                Title = ev.Title
            };

            return View(ed);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Confirm([Bind(Include = "EventId")] EventDisplay evt)
        {
            
            Event ev = db.Events.Find(evt.EventId);
            if (ev == null)
            {
                return HttpNotFound();
            }
            ev.Status = 1;
            ev.Confirmer = User.Identity.Name;
            db.Entry(ev).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        
    }
}