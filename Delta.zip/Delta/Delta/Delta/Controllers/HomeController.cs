﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Delta.Controllers
{
    public class HomeController : Controller
    {

        public ActionResult Index()
        {
            DeltaContext db = new DeltaContext();
            var user = db.FlowUsers.Where(mr => mr.Name == User.Identity.Name).FirstOrDefault();
            if (user == null)
            {
                db.FlowUsers.Add(new FlowUser { Name = User.Identity.Name });
                db.SaveChanges();
            }

            if (db.WorkItems.Count() == 0)
            {
                Seed.GetSeed();
            }

            return View();
        }

        public ActionResult GetTriageItems()
        {
            DeltaContext db = new DeltaContext();
            var ct = db.WorkItems.Where(re => re.TeamWorkItemId == 0).Count();
            return Content(ct.ToString());
        }

        public ActionResult GetRequiringAction()
        {
            DeltaContext db = new DeltaContext();
            var ct = (from fu in db.FlowUsers
                          join fug in db.FlowUserGroup on fu.FlowUserId equals fug.FlowUserId
                          join fg in db.FlowGroups on fug.FlowGroupId equals fg.FlowGroupId
                          join fgs in db.FlowGroupSteps on fg.FlowGroupId equals fgs.FlowGroupId
                          join fs in db.FlowSteps on fgs.FlowStepId equals fs.FlowStepId
                          join ch in db.Changes on fs.FlowStepParentId equals ch.CurrentStep
                          join cursp in db.FlowSteps on ch.CurrentStep equals cursp.FlowStepId
                          join cat in db.ChangeCategories on ch.Category equals cat.ChangeCategoryId
                          where fu.Name == User.Identity.Name
                          select new { ch.ChangeId, ch.Title, ch.ShortDescription, ch.Description, cat.Name, cursp.StepName }).Count();
            return Content(ct.ToString());
        }

        public ActionResult GetTotalEvents()
        {
            DeltaContext db = new DeltaContext();
            var ct = db.Events.Count();
            return Content(ct.ToString());
        }

        public ActionResult GetTotalChanges()
        {
            DeltaContext db = new DeltaContext();
            var ct = db.Changes.Count();
            return Content(ct.ToString());
        }
    }
}