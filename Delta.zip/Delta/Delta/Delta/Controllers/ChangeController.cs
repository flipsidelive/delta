﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace Delta.Controllers
{
    public class ChangeController : Controller
    {
        private DeltaContext db = new DeltaContext();
        // GET: Change
        public ActionResult Index()
        {
            var mylist = (from ch in db.Changes 
                          join cursp in db.FlowSteps on ch.CurrentStep equals cursp.FlowStepId
                          join cat in db.ChangeCategories on ch.Category equals cat.ChangeCategoryId                        
                          select new { ch.ChangeId, ch.Title, ch.ShortDescription, ch.Description, cat.Name, cursp.StepName }).ToList();

            List<ChangeMyActions> MyActions = new List<ChangeMyActions>();
            foreach (var v in mylist)
            {
                ChangeMyActions cma = new ChangeMyActions { Id = v.ChangeId, Title = v.Title, ShortDescription = v.ShortDescription, Category = v.Name, Status = v.StepName };
                MyActions.Add(cma);
            }

            return View(MyActions);            
        }

        public ActionResult Create()
        {
            ChangeDisplay ch = new ChangeDisplay();            
            ch.CreatedBy = User.Identity.Name;
            return View(ch);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ChangeId,Title,Description,Category,Status,Priority,FileIds")] ChangeDisplay newChange)
        {
            if (ModelState.IsValid)
            {
                Change ch = new Change();
                ch.Category = newChange.Category;
                ch.CreatedDate = DateTime.Now;
                ch.Description = newChange.Description;
                ch.ShortDescription = DeltaUtils.StripTagsRegexCompiled(newChange.Description);
                ch.CreatedBy = User.Identity.Name;
                ch.Title = newChange.Title;
                db.Changes.Add(ch);
                db.SaveChanges();
                var flowStep = (from fs in db.FlowSteps
                                join fl in db.Flows on fs.FlowId equals fl.FlowId
                                join chc in db.ChangeCategories on fl.FlowId equals chc.FlowId
                                where chc.ChangeCategoryId == newChange.Category && fs.FlowStepParentId == -1
                                select new { fs.StepName, fs.FlowStepId }).First();
                ChangeStep chs = new ChangeStep();
                chs.StepId = flowStep.FlowStepId;
                chs.ChangeId = ch.ChangeId;
                chs.TransitionDate = DateTime.Now;
                chs.Transitioner = User.Identity.Name;
                db.ChangeSteps.Add(chs);
                db.SaveChanges();
                ch.CurrentStep = chs.StepId;
                db.SaveChanges();

                SaveFilesToChange(newChange.FileIds, ch.ChangeId);

                return RedirectToAction("Index", "Home");
            }
            return View(newChange);
        }

        [HttpPost]
        public ActionResult AddFile()
        {
            bool isSavedSuccessfully = true;
            string fName = "";
            List<int> idAdd = new List<int>();
            try
            {
                foreach (string fileName in Request.Files)
                {
                    HttpPostedFileBase file = Request.Files[fileName];
                    //Save file content goes here
                    fName = file.FileName;
                    if (file != null && file.ContentLength > 0)
                    {
                        AttachedFile af = new AttachedFile();
                        af.FileName = fName;
                        af.FilePath = "Temp";
                        af.AttachmentType = "C"; //For Change
                        af.AttachedDate = DateTime.Now;
                        DeltaContext dc = new DeltaContext();
                        dc.AttachedFiles.Add(af);
                        dc.SaveChanges();
                        var originalDirectory = new DirectoryInfo(string.Format("{0}Images\\TempFiles", Server.MapPath(@"\")));
                        string pathString = System.IO.Path.Combine(originalDirectory.ToString(), af.AttachedFileId.ToString());

                        bool isExists = System.IO.Directory.Exists(pathString);
                        if (!isExists)
                            System.IO.Directory.CreateDirectory(pathString);
                        var path = string.Format("{0}\\{1}", pathString, file.FileName);
                        file.SaveAs(path);
                        idAdd.Add(af.AttachedFileId);
                    }

                }

            }
            catch (Exception ex)
            {
                isSavedSuccessfully = false;
            }


            if (isSavedSuccessfully)
            {
                return Json(new { Message = fName, id = string.Join(",", idAdd) });
            }
            else
            {
                return Json(new { Message = "Error in saving file" });
            }
        }

        private void SaveFilesToChange(string newChangeFileIds, int evChangeId)
        {
            if (newChangeFileIds.Length > 0)
            {
                string[] proIDs = newChangeFileIds.Replace("\"", "").Replace("[", "").Replace("]", "").Split(',');

                var destinationDirectory = new DirectoryInfo(string.Format("{0}Images\\StoredFiles", Server.MapPath(@"\")));
                string destinationIDDirectory = System.IO.Path.Combine(destinationDirectory.ToString(), "C"+evChangeId.ToString());

                bool isExists = System.IO.Directory.Exists(destinationIDDirectory);
                if (!isExists)
                    System.IO.Directory.CreateDirectory(destinationIDDirectory);

                foreach (var s in proIDs)
                {
                    int si = int.Parse(s);
                    var thisFileRecord = db.AttachedFiles.Where(ro => ro.AttachedFileId == si).FirstOrDefault();
                    var sourceDirectory = new DirectoryInfo(string.Format("{0}Images\\TempFiles", Server.MapPath(@"\")));
                    string sourceIDDirectory = System.IO.Path.Combine(sourceDirectory.ToString(), s);
                    string sourceFile = System.IO.Path.Combine(sourceIDDirectory, thisFileRecord.FileName);
                    string destFile = System.IO.Path.Combine(destinationIDDirectory, thisFileRecord.FileName);
                    System.IO.File.Move(sourceFile, destFile);
                    System.IO.Directory.Delete(sourceIDDirectory);
                    thisFileRecord.FilePath = destFile;
                    thisFileRecord.ParentId = evChangeId;
                    db.Entry(thisFileRecord).State = EntityState.Modified;
                    db.SaveChanges();
                }
            }
        }


        public ActionResult MyActions()
        {
            var mylist = (from fu in db.FlowUsers
                          join fug in db.FlowUserGroup on fu.FlowUserId equals fug.FlowUserId
                          join fg in db.FlowGroups on fug.FlowGroupId equals fg.FlowGroupId
                          join fgs in db.FlowGroupSteps on fg.FlowGroupId equals fgs.FlowGroupId
                          join fs in db.FlowSteps on fgs.FlowStepId equals fs.FlowStepId
                          join ch in db.Changes on fs.FlowStepParentId equals ch.CurrentStep
                          join cursp in db.FlowSteps on ch.CurrentStep equals cursp.FlowStepId
                          join cat in db.ChangeCategories on ch.Category equals cat.ChangeCategoryId
                          where fu.Name == User.Identity.Name
                          select new { ch.ChangeId, ch.Title, ch.ShortDescription, ch.Description, cat.Name, cursp.StepName }).Distinct().ToList();

            List<ChangeMyActions> MyActions = new List<ChangeMyActions>();
            foreach(var v in mylist)
            {
                ChangeMyActions cma = new ChangeMyActions { Id=v.ChangeId, Title = v.Title, ShortDescription = v.ShortDescription, Category = v.Name, Status = v.StepName };
                MyActions.Add(cma);
            }

            return View(MyActions);
        }

        public ActionResult Move(int? id)
        {
            if (id == null)
            {
                Response.Redirect("/");
            }
            var ev = (from ch in db.Changes
                          join cursp in db.FlowSteps on ch.CurrentStep equals cursp.FlowStepId
                          join cat in db.ChangeCategories on ch.Category equals cat.ChangeCategoryId
                          where ch.ChangeId == id
                          select new { ch.ChangeId, ch.Title, ch.ShortDescription, ch.Description, cat.Name, cursp.StepName, ch.CurrentStep }).FirstOrDefault();
            var ActNames = (from fsp in db.FlowSteps where fsp.FlowStepParentId == ev.CurrentStep select new { fsp.TransitionIn }).ToList();

            if (ev == null)
            {
                return HttpNotFound();
            }

            ChangeMove cma = new ChangeMove { Id = ev.ChangeId, Title = ev.Title, Description = ev.Description, Category = ev.Name, Status = ev.StepName };
            foreach(var act in ActNames)
            {                
                cma.Actions.Add(act.TransitionIn);
            }

            return View(cma);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Move(string button, int id)
        {
            var actionId = (from ac in db.FlowSteps where ac.TransitionIn == button select ac.FlowStepId).FirstOrDefault();

            var thisChange = db.Changes.Find(id);
            thisChange.CurrentStep = actionId;
            db.Entry(thisChange).State = EntityState.Modified;
            db.SaveChanges();

            ChangeStep chs = new ChangeStep();
            chs.StepId = actionId;
            chs.ChangeId = thisChange.ChangeId;
            chs.TransitionDate = DateTime.Now;
            chs.Transitioner = User.Identity.Name;
            db.ChangeSteps.Add(chs);
            db.SaveChanges();

            return RedirectToAction("/", "Home");
        }   
        
        public ActionResult GetFlows(string CategoryName)
        {
            int CatInt = int.Parse(CategoryName);

            var flowSteps = (from fs in db.FlowSteps
                             join fl in db.Flows on fs.FlowId equals fl.FlowId
                             join ch in db.ChangeCategories on fl.FlowId equals ch.FlowId
                             where ch.ChangeCategoryId == CatInt
                             select new { fs.StepName }).ToList();

            if (flowSteps.Count > 0)
            {
                StringBuilder sb = new StringBuilder("<h5>These are the steps the selected category will pass through.</h5><ul>");
                foreach (var nm in flowSteps)
                {
                    string StepName = nm.StepName;
                    if (string.IsNullOrEmpty(StepName))
                    {
                        StepName = "Requested";
                    }
                    sb.AppendFormat("<li>{0}</li>", StepName);
                }
                sb.Append("</ul>");
                return Content(sb.ToString());
            }
            else
            {
                return Content("Pick a category with a valid workflow.");
            }

            
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                Response.Redirect("/");
            }
            Change ch = db.Changes.Find(id);
            if (ch == null)
            {
                return HttpNotFound();
            }

            ChangeDisplay cd = new ChangeDisplay
            {
                Category = ch.Category,
                ChangeId = ch.ChangeId,
                CreatedBy = ch.CreatedBy,
                CreatedDate = ch.CreatedDate,
                CurrentStep = ch.CurrentStep,
                Description = ch.Description,
                ShortDescription = ch.ShortDescription,
                Title = ch.Title
            };

            var AttachedFiles = (from af in db.AttachedFiles
                                 where af.AttachmentType == "C" && af.ParentId == ch.ChangeId
                                 select new { af.FileName, af.FilePath }).ToList();

            cd.AttachedFiles = new List<AttachedFile>();
            if (AttachedFiles.Count > 0)
            {
                foreach (var AttachedFile in AttachedFiles)
                {
                    cd.AttachedFiles.Add(new Delta.AttachedFile { FileName = AttachedFile.FileName, FilePath = MapPathReverse(AttachedFile.FilePath) });
                }
            }

            return View(cd);
        }

        public static string MapPathReverse(string AbsolutePath)
        {
            return AbsolutePath.Replace(HostingEnvironment.ApplicationPhysicalPath, "/").Replace(@"\", "/");
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ChangeId,Title,Description")] ChangeDisplay chg)
        {
            if (ModelState.IsValid)
            {

                var old = db.Changes.Find(chg.ChangeId);
                old.Title = chg.Title;
                old.Description = chg.Description;
                old.ShortDescription = DeltaUtils.StripTagsRegexCompiled(chg.Description);
                db.Entry(old).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("/", "Home");
            }
            return View(chg);
        }
    }
}