﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Delta.Controllers
{
    public class TimelineController : Controller
    {

        private DeltaContext db = new DeltaContext();
        // GET: Timeline
        public ActionResult Index()
        {
            List<EventDisplay> ed = new List<EventDisplay>();
            var origList = (from ev in db.Events
                            join ct in db.EventCategories on ev.Category equals ct.EventCategoryId                            
                            orderby ev.EventDate descending
                            select new { ev, ct }).ToList();
            

            foreach (var o in origList)
            {

                string sortedRequestor = DeltaUtils.CleanUsername(o.ev.Requestor);
                ed.Add(
                    new EventDisplay
                    {
                        Title = o.ev.Title,
                        EventId = o.ev.EventId,
                        CategoryName = o.ct.Name,
                        CreatedDate = o.ev.CreatedDate,
                        Description = o.ev.Description,
                        CleanedRequestor = sortedRequestor,
                        EventDate = o.ev.EventDate,
                        Planned = o.ev.Planned,
                        Status = o.ev.Status,
                        StatusText = SetStatusText(o.ev.Status),
                        ShortDescription = DeltaUtils.Left(o.ev.ShortDescription, 500),
                        Confirmer = o.ev.Confirmer
                        // Status = o.ch.Status.ToString()
                    });
            }
            return View(ed);
        }

        private string SetStatusText(int status)
        {
            if (status == 0)
            {
                return "Pending";
            }
            else
            {
                return "Completed";
            }
        }
    }
}