namespace Delta.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ChangeCategories",
                c => new
                    {
                        ChangeCategoryId = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        ParentId = c.Int(),
                    })
                .PrimaryKey(t => t.ChangeCategoryId);
            
            CreateTable(
                "dbo.WorkItems",
                c => new
                    {
                        WorkItemId = c.Int(nullable: false, identity: true),
                        Title = c.String(nullable: false),
                        Category = c.Int(nullable: false),
                        ShortDescription = c.String(),
                        Description = c.String(),
                        CreatedDate = c.DateTime(nullable: false),
                        CompletedDate = c.DateTime(),
                        Priority = c.Int(nullable: false),
                        Status = c.Int(nullable: false),
                        Requestor = c.String(),
                        TeamWorkItemId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.WorkItemId);
            
            CreateTable(
                "dbo.EventCategories",
                c => new
                    {
                        EventCategoryId = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        ParentId = c.Int(),
                    })
                .PrimaryKey(t => t.EventCategoryId);
            
            CreateTable(
                "dbo.Events",
                c => new
                    {
                        EventId = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        ShortDescription = c.String(),
                        Description = c.String(),
                        EventDate = c.DateTime(nullable: false),
                        Requestor = c.String(nullable: false),
                        Confirmer = c.String(),
                        CreatedDate = c.DateTime(nullable: false),
                        Status = c.Int(nullable: false),
                        Planned = c.Boolean(nullable: false),
                        CleanedRequestor = c.String(),
                        Discriminator = c.String(nullable: false, maxLength: 128),
                        Category_EventCategoryId = c.Int(),
                    })
                .PrimaryKey(t => t.EventId)
                .ForeignKey("dbo.EventCategories", t => t.Category_EventCategoryId)
                .Index(t => t.Category_EventCategoryId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Events", "Category_EventCategoryId", "dbo.EventCategories");
            DropIndex("dbo.Events", new[] { "Category_EventCategoryId" });
            DropTable("dbo.Events");
            DropTable("dbo.EventCategories");
            DropTable("dbo.WorkItems");
            DropTable("dbo.ChangeCategories");
        }
    }
}
