﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace Delta
{
    public class WorkItemDisplay
    {
        public WorkItemDisplay()
        {
            AttachedFiles = new List<AttachedFile>();
        }

        public int WorkItemId { get; set; }
        [Display(Name = "Title")]
        public string Title { get; set; }    
        public int CategoryId { get; set; }  
        public String Category { get; set; }
        [Display(Name = "Short Description")]
        public string ShortDescription { get; set; }
        [AllowHtml]
        public string Description { get; set; }
        [Display(Name = "Created Date")]
        public DateTime CreatedDate { get; set; }
        public DateTime? CompletedDate { get; set; }
        public PriorityEnum Priority { get; set; }
        public string Status { get; set; }
        public int StatusId { get; set; }
        public List<StatusDropDown> StatusDrop { get; set; }
        public string CleanedRequestor { get; set; }
        public string Requestor { get; set; }
        public int TfsWorkItemId { get; set; }
        public string FileIds { get; set; }
        public List<AttachedFile> AttachedFiles { get; set; }
        public bool MoveToTfsPermission { get; set; }
    }
}