﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace Delta
{    

    public class ChangeDisplay
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ChangeId { get; set; }
        [Display(Name = "Title")]
        public string Title { get; set; }
        public int Category { get; set; }
        [Display(Name = "Description")]
        public string ShortDescription { get; set; }
        [AllowHtml]
        public string Description { get; set; }        
        [Display(Name = "Requested Date & Time")]
        public DateTime CreatedDate { get; set; }
        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }
        public int CurrentStep { get; set; }
        [Display(Name = "Attach Files")]
        public string FileIds { get; set; }
        public List<AttachedFile> AttachedFiles { get; set; }

    }
}