﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Delta
{
    public class StatusDropDown
    {
        public int StatusId { get; set; }
        public string StatusValue { get; set; }
    }
}