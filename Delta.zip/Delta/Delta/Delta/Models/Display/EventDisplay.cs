﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace Delta
{

    public class EventDisplay
    {

        public int EventId { get; set; }
        [Display(Name = "Title")]
        [Required]
        public string Title { get; set; }
        public int Category { get; set; }
        [Display(Name = "Category")]
        public string CategoryName { get; set; }
        [Display(Name = "Description")]
        public string ShortDescription { get; set; }
        [AllowHtml]
        public string Description { get; set; }
        [Display(Name = "Event Date & Time")]
        public DateTime EventDate { get; set; }
        [Required]
        public string Requestor { get; set; }
        [Display(Name = "Confirmed By")]
        public string Confirmer { get; set; }
        [Display(Name = "Created Date")]
        public DateTime CreatedDate { get; set; }
        public int Status { get; set; }
        [Display(Name = "Status")]
        public string StatusText { get; set; }
        public bool Planned { get; set; }
        public string CleanedRequestor { get; set; }
        [Display(Name = "Event Date")]
        public string EventDateString { get; set; }
        [Display(Name = "Event Time")]
        public string EventTimeString { get; set; }
        [Display(Name = "Attach Files")]
        public string FileIds { get; set; }
        public List<AttachedFile> AttachedFiles {get; set;}
    }
}