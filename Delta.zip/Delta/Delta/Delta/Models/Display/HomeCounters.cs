﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Delta.Models.Display
{
    public class HomeCounters
    {
        public int TriageItems { get; set; }
        public int NeedingAction { get; set; }
    }
}