﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Delta
{
    public class ChangeCategoryDisplay
    {
        public ChangeCategoryDisplay()
        {
            Children = new List<ChangeCategoryDisplay>();
        }
           
        public int ChangeCategoryId { get; set; }
        public string Name { get; set; }
        public List<ChangeCategoryDisplay> Children { get; set; }
    }
}