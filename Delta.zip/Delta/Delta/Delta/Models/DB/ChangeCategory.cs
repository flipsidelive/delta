﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Delta
{
    public class ChangeCategory
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ChangeCategoryId { get; set; }
        public string Name { get; set; }
        public int? ParentId { get; set; }
        public int FlowId { get; set; }
    }
}