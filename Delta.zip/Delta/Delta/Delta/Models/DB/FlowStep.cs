﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Delta
{
    public class FlowStep
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int FlowStepId { get; set; }
        public int FlowId { get; set; }
        public int FlowStepParentId { get; set; }
        public string StepName { get; set; }
        public string TransitionIn { get; set; }
    }
}