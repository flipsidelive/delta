﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace Delta
{
    public enum StatusEnum
    {
        New,
        Removed,
        Approved,
        Committed,
        Testing,
        Done        
    }

    public enum PriorityEnum
    {
        Low,
        Medium,
        High,
        Critical
    }

    public class WorkItem
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int WorkItemId { get; set; }
        [Display(Name = "Title")]
        [Required]
        public string Title { get; set; }
        [Required]
        public int Category { get; set; }
        [Display(Name = "Short Description")]
        public string ShortDescription { get; set; }
        [AllowHtml]
        public string Description { get; set; }
        [Display(Name = "Created Date")]
        public DateTime CreatedDate { get; set; }
        public DateTime? CompletedDate { get; set; }
        public PriorityEnum Priority { get; set; }
        public StatusEnum Status { get; set; }
        public string Requestor { get; set; }        
        public int TeamWorkItemId { get; set; }
    }
}