﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace Delta
{    

    public class Event
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int EventId { get; set; }
        [Display(Name = "Title")]
        public string Title { get; set; }
        public int Category { get; set; }
        [Display(Name = "Short Description")]
        public string ShortDescription { get; set; }
        [AllowHtml]
        public string Description { get; set; }        
        [Display(Name = "Event Date & Time")]
        public DateTime EventDate { get; set; }
        [Required]
        public string Requestor { get; set; }
        public string Confirmer { get; set; }
        public DateTime CreatedDate { get; set; }
        public int Status { get; set; }
        public bool Planned { get; set; }

    }
}