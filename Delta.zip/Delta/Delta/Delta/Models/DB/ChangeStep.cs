﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace Delta
{    

    public class ChangeStep
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ChangeStepId { get; set; }
        public int ChangeId { get; set; }
        public int StepId { get; set; }
        public DateTime TransitionDate { get; set; }
        public string Transitioner { get; set; }

    }
}